/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.DAO;

import java.sql.*;
import model.Cliente;
import config.ConectaDB;
/**
 *
 * @author Matheus Gabriel
 * 28/08/2025
 */
public class ClienteDAO {
    //crud create read update delete
    public boolean cadastro(Cliente p_cliente) throws ClassNotFoundException{
      
        Connection conn = null;
        try {
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();
            String sql = "INSERT INTO `clientes`(`nome`, `email`, `renda`) VALUES('"+p_cliente.getNome()+"','"+p_cliente.getEmail()+"',"+p_cliente.getRenda()+");";
            stmt.executeUpdate(sql);//insert delete update
            
            System.out.println("Registro incluido com sucesso");
             return true;
        } catch (SQLException ex) {
            return false;
        }
        
        
       
    }
    
    
    
    
}
