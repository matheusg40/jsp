/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 * @author Adilson Lima
 * Data: 21/08/2025 
 */
public class Cliente {
    // Atributos
    private int id;
    private String nome;
    private String email;
    private float renda;
    
    // Métodos
    public void setId(int p_id) {
        this.id = p_id;
    }
    public void setNome(String p_nome) {
        this.nome = p_nome;
    }
    public void setEmail(String p_email) {
        this.email = p_email;
    }
    public void setRenda(float p_renda) {
        this.renda = p_renda;
    }

    public int getId() {
        return this.id;
    }
    public String getNome() {
        return this.nome;
    }
    public String getEmail() {
        return this.email;
    }
    public float getRenda() {
        return this.renda;
    }            
}
