/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author alunocmc
 */
public class Produtos {
    
 //atributos 
    private int id;
    private String nome;
    private float valor;
       
    
   //metodos
    public void setId(int p_id) {
        this.id = p_id;
    }
    public void setNome(String p_nome) {
        this.nome = p_nome;
    }
    public void setValor(float p_valor) {
        this.valor = p_valor;
    }
       public int getId() {
        return this.id;
    }
    public String getNome() {
        return this.nome;
    }
    public float getValor() {
        return this.valor;
    }
    
    
}
