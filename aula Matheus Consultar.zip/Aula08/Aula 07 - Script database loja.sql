create database loja;
create TABLE clientes ( pk_id int not null PRIMARY KEY AUTO_INCREMENT, nome varchar(40) NOT null, email varchar(30) NOT null, renda float NOT null);
Insert INTO clientes (nome, email, renda) VALUES ('Ana Maria', 'ana@umc.br', 9850.75);
Insert INTO clientes (nome, email, renda) VALUES ('João da Silva', 'js@umc.br', 10550.50);
select nome from clientes;
select * from clientes;
select * from clientes where nome = 'ana';
select * from clientes where nome like 'ana%';
select * from clientes where nome = 'ana maria';