/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.DAO;

import java.sql.*;
import model.Cliente;
import config.ConectaDB;
import java.util.ArrayList;
import java.util.List;

        
/** @author Adilson Lima
 * Data: 28/08/2025
 */
public class ClienteDAO {
    // Atrib
    
    //Métodos - CRUD
    public boolean cadastrar( Cliente p_cliente ) throws ClassNotFoundException{
        Connection conn = null;        
        try{           
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();
            String sql = "Insert INTO clientes (nome, email, renda) VALUES ('"+ p_cliente.getNome() +"', '" +p_cliente.getEmail() + "', " + p_cliente.getRenda() + ")";            
            stmt.executeUpdate(sql); //Insert / Delete / Update
            System.out.println("Registro incluído com sucesso!");
            conn.close();
            return true;
        }catch(SQLException ex){
            return false;
        }        
    }

    public List consulta_geral() throws ClassNotFoundException{
        List lst = new ArrayList();
        Connection conn = null;        
        try{           
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();
            //            select * from clientes
            String sql = "select * from clientes order by nome";  
            ResultSet rs = stmt.executeQuery(sql);
            
            // Apresentar o resultado do "rs"
            int n_reg = 0;
            while (rs.next()){
                Cliente cli = new Cliente();
                cli.setId(Integer.parseInt(rs.getString("pk_id")));
                cli.setNome(rs.getString("nome"));
                cli.setEmail(rs.getString("email"));
                cli.setRenda(Float.parseFloat( rs.getString("renda")) );
                lst.add(cli);                
                //System.out.println(rs.getString("pk_id") + " - " + rs.getString("nome"));
                n_reg++;
            }
            
            conn.close();
            
            if (n_reg == 0){
                return null;
            }else{             
                return lst;
            }            
        }catch(SQLException ex){
            return null;
        }        
    }
    public Cliente consulta_id(Cliente cli) throws ClassNotFoundException{
        Connection conn = null;        
        try{           
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();
            //            select * from clientes
            String sql = "select * from clientes where pk_id = " + cli.getId();  
            ResultSet rs = stmt.executeQuery(sql);
            
            // Apresentar o resultado do "rs"
            int n_reg = 0;
            
            while (rs.next()){
                cli.setId(Integer.parseInt(rs.getString("pk_id")));
                cli.setNome(rs.getString("nome"));
                cli.setEmail(rs.getString("email"));
                cli.setRenda(Float.parseFloat( rs.getString("renda")) );
                      
                //System.out.println(rs.getString("pk_id") + " - " + rs.getString("nome"));
                n_reg++;
            }
            
            conn.close();
            
            if (n_reg == 0){
                return null;
            }else{             
                return cli;
            }            
        }catch(SQLException ex){
            return null;
        }        
    }
}
